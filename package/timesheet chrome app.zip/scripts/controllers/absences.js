'use strict';

angular.module('timesheetApp')
    .service('AbsenceService', ['$http', '$q', 'urls',
        function ($http, $q, urls) {
            var index = urls.absences.index;
            var detail = urls.absences.detail;
            return {
                getAll: function () {
                    var deferred = $q.defer();
                    $http.get(index).success(function (absences) {
                        deferred.resolve(absences);
                    }).error(function (err) {
                        deferred.reject(err);
                    });
                    return deferred.promise;
                },
                save: function (absences) {
                    var promises = absences.map(function (absence) {
                        return $http.post(index, absence);
                    });

                    return $q.all(promises);
                },
                remove: function (id) {
                    var deferred = $q.defer();
                    $http.delete(detail + id).success(function () {
                        deferred.resolve();
                    }).error(function (err) {
                        deferred.reject(err);
                    });
                    return deferred.promise;
                }
            };
        }
    ]).controller('AbsencesController', function ($scope, $http, $location, $ionicLoading, AbsenceService, $ionicPopup) {
        //todo: refactor loading stuff in decorator
        $ionicLoading.show({
            template: 'Loading...'
        });
        $scope.doRefresh = function () {
            AbsenceService.getAll().then(function (absences) {
                absences = _.sortBy(absences, function(absence) {
                    var t = new Date(absence.date);
                    return t.getDate() + (t.getMonth() + 1) + t.getFullYear();
                });

                


                absences = _.map(absences, function (absence) {
                    var t = new Date(absence.date);
                    absence.formattedTime = t.getDate() + "/" + (t.getMonth() + 1) + "/" + t.getFullYear();
                    return absence;
                });
                $scope.absences = absences;
                $ionicLoading.hide();
            }).finally(function () {
                // Stop the ion-refresher from spinning
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        $scope.doRefresh();

        $scope.remove = function (id) {
            var confirmPopup = $ionicPopup.confirm({
                title: 'Delete',
                template: 'Are you sure you want to delete this absence?'
            });
            confirmPopup.then(function (res) {
                if (res) {
                    AbsenceService.remove(id).then(function () {
                        $scope.doRefresh();
                    });
                }
            });
        };
    }).controller('AbsencesDetailController', function ($stateParams, $scope, AbsenceService, dateFilter, $state, $ionicPopup) {
        $scope.absence = {
            from: dateFilter(new Date(), 'yyyy-MM-dd'),
            to: dateFilter(new Date(), 'yyyy-MM-dd')
        };

        $scope.save = function (valid) {
            $scope.submitted = true;
            if (!valid) {
                return;
            }

            var absence = $scope.absence;
            var data = [];
            for (var d = new Date(absence.from); d <= new Date(absence.to); d.setDate(d.getDate() + 1)) {
                data.push({
                    year: dateFilter(d, 'yyyy'),
                    month: dateFilter(d, 'MM'),
                    day: dateFilter(d, 'dd'),
                    amount: 1
                });
            }

            AbsenceService.save(data).then(function (results) {
                var success = true;

                _.forEach(results, function (result) {
                    if (!result.data.success) {
                        success = false;
                        $ionicPopup.alert({
                            title: 'Absence registration failed',
                            template: result.data.message
                        });
                    }
                });

                if (success) {
                    $state.go('gretel.home');
                }
            });
        };
    });