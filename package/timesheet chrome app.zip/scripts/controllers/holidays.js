'use strict';

angular.module('timesheetApp')

.service("HolidayService", ['$http', '$q',
    function ($http, q) {

        var testData = [{
            name: "Onze Lieve Heer Hemelvaart",
            date: new Date(2014, 8, 15),
            id: 1
        }, {
            name: "Wapenstilstand",
            date: new Date(2014, 1, 11),
            id: 2
        }];
        return {
            getAll: function () {
                var deferred = q.defer();
                $http.get('http://timesheetservice.herokuapp.com/timeandwork/holidays').success(function (holidays) {
                    deferred.resolve(holidays);
                }).error(function (err) {
                    deferred.reject(err);
                });
                return deferred.promise;
            },
            getById: function (id) {
                var deferred = q.defer();
                $http.get('http://timesheetservice.herokuapp.com/timeandwork/holidays/' + id).success(function (holiday) {
                    deferred.resolve(holiday);
                }).error(function (err) {
                    deferred.reject(err);
                });
                return deferred.promise;
            }
        }
    }
]).controller('HolidaysController', function ($scope, $http, $location, $ionicLoading, HolidayService) {
    //todo: refactor loading stuff in decorator
    $ionicLoading.show({
        template: 'Loading...'
    });
    HolidayService.getAll().then(function (holidays) {
        $scope.holidays = holidays;
        $ionicLoading.hide();
    })

    $scope.remove = function (item) {
        var index = $scope.holidays.indexOf(item)
        $scope.holidays.splice(index, 1);
    };
}).controller('HolidaysDetailController', function ($stateParams, $scope, HolidayService, dateFilter) {
    var id = $stateParams.id;   
    HolidayService.getById(id).then(function (holiday) {
        holiday.date = dateFilter(new Date(holiday.date), 'yyyy-MM-dd');
        $scope.holiday = holiday;
    })
});