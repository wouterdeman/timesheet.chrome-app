'use strict'



angular.module('timesheetApp', ['ionic', 'highcharts-ng']).factory('chromeApp', function () {
    return chromeApp;
});
