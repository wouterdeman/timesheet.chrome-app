'use strict'



angular.module('timesheetApp', ['ionic']).factory('chromeApp', function () {
  return chromeApp;
});